{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "1b355c86-caea-484f-8b84-58c879d8582c",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "",
   "name": ""
  },
  "language_info": {
   "name": ""
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
